package com.linkedList.singlyLinkedList;



//Recursive Java program to count number of nodes in 
//a linked list 

/* Linked list Node*/
class Node1 
{ 
	int data; 
	Node1 next; 
	Node1(int d) { data = d; next = null; } 
} 

//Linked List class 
class lengthOfListRecursive 
{ 
	Node1 head; // head of list 

	/* Inserts a new Node at front of the list. */
	public void push(int new_data) 
	{ 
		/* 1 & 2: Allocate the Node & 
				Put in the data*/
		Node1 new_node = new Node1(new_data); 

		/* 3. Make next of new Node as head */
		new_node.next = head; 

		/* 4. Move the head to point to new Node */
		head = new_node; 
	} 

	/* Returns count of nodes in linked list */
	public int getCountRec(Node1 node) 
	{ 
		// Base case 
		if (node == null) 
			return 0; 

		// Count is this node plus rest of the list 
		return 1 + getCountRec(node.next); 
	} 

	/* Wrapper over getCountRec() */
	public int getCount() 
	{ 
		return getCountRec(head); 
	} 

	/* Driver program to test above functions. Ideally 
	this function should be in a separate user class. 
	It is kept here to keep code compact */
	public static void main(String[] args) 
	{ 
		/* Start with the empty list */
		lengthOfListRecursive llist = new lengthOfListRecursive(); 
		llist.push(1); 
		llist.push(3); 
		llist.push(1); 
		llist.push(2); 
		llist.push(1); 

		System.out.println("Count of nodes is " + 
						llist.getCount()); 
	} 
} 
