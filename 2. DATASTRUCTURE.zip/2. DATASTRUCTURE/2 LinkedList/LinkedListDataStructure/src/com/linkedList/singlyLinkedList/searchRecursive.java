package com.linkedList.singlyLinkedList;


//Recursive Java program to search an element 
//in linked list 


//Node class 
class Node3 
{ 
	int data; 
	Node3 next; 
	Node3(int d) 
	{ 
		data = d; 
		next = null; 
	} 
} 

//Linked list class 
class searchRecursive 
{ 
	Node3 head; //Head of list 

	//Inserts a new node at the front of the list 
	public void push(int new_data) 
	{ 
		//Allocate new node and putting data 
		Node3 new_node = new Node3(new_data); 

		//Make next of new node as head 
		new_node.next = head; 

		//Move the head to point to new Node 
		head = new_node; 
	} 

	// Checks whether the value x is present 
	// in linked list 
	public boolean search(Node3 head, int x) 
	{ 
		// Base case 
		if (head == null) 
			return false; 

		// If key is present in current node, 
		// return true 
		if (head.data == x) 
			return true; 

		// Recur for remaining list 
		return search(head.next, x); 
	} 

	// Driver function to test the above functions 
	public static void main(String args[]) 
	{ 
		// Start with the empty list 
		searchRecursive llist = new searchRecursive(); 

		/* Use push() to construct below list 
		14->21->11->30->10 */
		llist.push(10); 
		llist.push(30); 
		llist.push(11); 
		llist.push(21); 
		llist.push(14); 

		if (llist.search(llist.head, 21)) 
			System.out.println("Yes"); 
		else
			System.out.println("No"); 
	} 
} 
//This code is contributed by Pratik Agarwal 
