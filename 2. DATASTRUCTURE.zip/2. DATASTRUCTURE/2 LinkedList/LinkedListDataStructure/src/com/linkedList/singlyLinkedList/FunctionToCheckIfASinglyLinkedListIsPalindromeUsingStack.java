package com.linkedList.singlyLinkedList;


/* Java program to check if linked list is palindrome recursively */
import java.util.*; 

class FunctionToCheckIfASinglyLinkedListIsPalindromeUsingStack { 
	public static void main(String args[]) 
	{ 
		Nod6 one = new Nod6(1); 
		Nod6 two = new Nod6(2); 
		Nod6 three = new Nod6(3); 
		Nod6 four = new Nod6(4); 
		Nod6 five = new Nod6(3); 
		Nod6 six = new Nod6(2); 
		Nod6 seven = new Nod6(1); 
		one.ptr = two; 
		two.ptr = three; 
		three.ptr = four; 
		four.ptr = five; 
		five.ptr = six; 
		six.ptr = seven; 
		boolean condition = isPalindrome(one); 
		System.out.println("isPalidrome :" + condition); 
	} 
	static boolean isPalindrome(Nod6 head) 
	{ 
		Nod6 slow = head; 
		boolean ispalin = true; 
		Stack<Integer> stack = new Stack<Integer>(); 

		while (slow != null) { 
			stack.push(slow.data); 
			slow = slow.ptr; 
		} 

		while (head != null) { 

			int i = stack.pop(); 
			if (head.data == i) { 
				ispalin = true; 
			} 
			else { 
				ispalin = false; 
				break; 
			} 
			head = head.ptr; 
		} 
		return ispalin; 
	} 
} 

class Nod6 { 
	int data; 
	Nod6 ptr; 
	Nod6(int d) 
	{ 
		ptr = null; 
		data = d; 
	} 
} 



