package com.linkedList.singlyLinkedList;



//Java code to implement binary search 
//on Singly Linked List 

//Node Class 
class Node8 
{ 
	int data; 
	Node8 next; 

	// Constructor to create a new node 
	Node8(int d) 
	{ 
		data = d; 
		next = null; 
	} 
} 

class BinarySearchOnSinglyLinkedList 
{ 
	// function to insert a node at the beginning 
	// of the Singaly Linked List 
	static Node8 push(Node8 head, int data) 
	{ 
		Node8 newNode = new Node8(data); 
		newNode.next = head; 
		head = newNode; 
		return head; 
	} 

	// Function to find middle element 
	// using Fast and Slow pointers 
	static Node8 middleNode(Node8 start, Node8 last) 
	{ 
		if (start == null) 
			return null; 

		Node8 slow = start; 
		Node8 fast = start.next; 

		while (fast != last) 
		{ 
			fast = fast.next; 
			if (fast != last) 
			{ 
				slow = slow.next; 
				fast = fast.next; 
			} 
		} 
		return slow; 
	} 

	// function to insert a node at the beginning 
	// of the Singly Linked List 
	static Node8 BinarySearchOnSinglyLinkedList(Node8 head, int value) 
	{ 
		Node8 start = head; 
		Node8 last = null; 

		do
		{ 
			// Find Middle 
			Node8 mid = middleNode(start, last); 

			// If middle is empty 
			if (mid == null) 
				return null; 

			// If value is present at middle 
			if (mid.data == value) 
				return mid; 

			// If value is less than mid 
			else if (mid.data > value) 
			{ 
				start = mid.next; 
			} 

			// If the value is more than mid. 
			else
				last = mid; 
		} while (last == null || last != start); 

		// value not present 
		return null; 
	} 

	// Driver Code 
	public static void main(String[] args) 
	{ 
		Node8 head = null; 

		// Using push() function to 
		// convert singly linked list 
		// 10 -> 9 -> 8 -> 7 -> 4 -> 1 
		head = push(head, 1); 
		head = push(head, 4); 
		head = push(head, 7); 
		head = push(head, 8); 
		head = push(head, 9); 
		head = push(head, 10); 
		int value = 7; 

		if (BinarySearchOnSinglyLinkedList(head, value) == null) 
		{ 
			System.out.println("Value not present"); 
		} 
		else
		{ 
			System.out.println("Present"); 
		} 
	} 
} 

//This code is contributed by Vivekkumar Singh 
